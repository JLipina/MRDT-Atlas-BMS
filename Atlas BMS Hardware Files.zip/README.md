Battery Management System- this year it DOES THINGS.

Right now we're on revision 1, which is the very basic BMS functionality: monitoring and reporting on the voltages and overall current of the battery pack; monitoring temperatures and controlling fans in response; indicators, including LED fuel gauge and buzzers; last but most important, the E-Stop. Based around the LTC6803, this board is streamlined, with inspiration taken from Zenith's BMS and Solar Car's designs.
Future goals:
	Onboard passive balancing
